import './App.css';

import Parallax from './components/ParallaxComponent.js';

function App() {
  return (
    <div className="App">
      <Parallax />
    </div>
  );
}

export default App;
